var app = angular.module('app', ['ngTouch', 'ui.grid']);

app.controller('MainCtrl', ['$scope', '$timeout', function ($scope, $timeout) {
  $scope.gridOptions = {
    enableSorting: true
  };

  var colCount = 500;
  var rowCount = 500;

  $scope.gridOptions.columnDefs = [];
  $timeout( function() {
    for (var colIndex = 0; colIndex < colCount; colIndex++) {
      $scope.gridOptions.columnDefs.push({
        name: 'col' + colIndex,
        width: Math.floor(Math.random() * (120 - 50 + 1)) + 50
      });
    }
  });

  var data = [];

  $timeout( function() {
    for (var rowIndex = 0; rowIndex < rowCount; rowIndex++) {
      var row = {};

      for (var colIndex = 0; colIndex < colCount; colIndex++) {
        row['col' + colIndex] = 'r' + rowIndex + 'c' + colIndex;
      }

      data.push(row);
    }
  });

  $scope.gridOptions.data = data;

  $scope.$on("destroy", function(){
    $timeout.cancel();
  });
}]);
